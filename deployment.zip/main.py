import os
import json
from typing import Dict, Optional, Any, List
import traceback
import asyncio
from datetime import datetime

import pulumi
import pulumi_azure_native as azure_native
from pulumi import automation as auto
from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from infra.resource_group import create_resource_group
from infra.vnet import create_vnet
from infra.subnet import create_subnet

# Function to check if a resource exists
# This will be imported by the infra modules
def check_resource_exists(resource_id: str) -> bool:
    """
    Check if an Azure resource exists by its resource ID.
    This is a placeholder function that always returns False by default.
    
    In a real production environment, this function would use Azure SDK to check
    if the resource exists before attempting to create or import it.
    
    Args:
        resource_id: The Azure resource ID to check
        
    Returns:
        bool: Whether the resource exists or not
    """
    # Default implementation always returns False
    # The actual implementation would use Azure SDK to check
    return False

app = FastAPI(title="Azure Provisioner")

# Add CORS middleware to allow cross-origin requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
app.mount("/static", StaticFiles(directory="frontend"), name="static")

# Pydantic models
class ProvisionRequest(BaseModel):
    resourceGroupName: str
    vnetName: str
    vnetCidr: str
    subnetName: str
    subnetCidr: str
    location: str = Field(default="eastus")
    tryImportExisting: bool = Field(default=False)

class ProvisionResponse(BaseModel):
    resourceGroupName: str
    vnetName: str
    subnetName: str
    outputs: Dict[str, Any]

class ErrorResponse(BaseModel):
    detail: str

class ResourceStatus(BaseModel):
    resource_type: str
    name: str
    status: str
    message: str
    timestamp: str
    details: Optional[Dict[str, Any]] = None
    progress: Optional[float] = None
    stage: Optional[str] = None

# Store for active WebSocket connections
active_connections: Dict[str, WebSocket] = {}

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    error_detail = str(exc)
    # Add traceback for non-production environments
    if os.environ.get("ENV") != "production":
        error_detail += "\n\n" + traceback.format_exc()
    
    return JSONResponse(
        status_code=500,
        content={"detail": f"Internal Server Error: {error_detail}"}
    )

# Serve the frontend
@app.get("/")
async def get_index():
    return FileResponse("frontend/index.html")

# WebSocket endpoint for live resource creation status
@app.websocket("/ws/status/{client_id}")
async def websocket_status(websocket: WebSocket, client_id: str):
    await websocket.accept()
    active_connections[client_id] = websocket
    try:
        # Keep connection alive
        while True:
            # Just echo any messages received (not using them for anything in this demo)
            data = await websocket.receive_text()
            # You could process commands from the client here
    except WebSocketDisconnect:
        # Remove connection when client disconnects
        if client_id in active_connections:
            del active_connections[client_id]

# Function to send resource status updates to all connected clients
async def broadcast_resource_status(
    resource_type: str, 
    name: str, 
    status: str, 
    message: str, 
    details: Optional[Dict[str, Any]] = None,
    progress: Optional[float] = None,
    stage: Optional[str] = None
):
    if not active_connections:
        return
    
    # Create a detailed timestamp with microseconds
    now = datetime.now()
    formatted_timestamp = now.isoformat(timespec='microseconds')
    
    status_update = ResourceStatus(
        resource_type=resource_type,
        name=name,
        status=status,
        message=message,
        timestamp=formatted_timestamp,
        details=details,
        progress=progress,
        stage=stage
    )
    
    # Convert to JSON
    status_json = status_update.model_dump() if hasattr(status_update, 'model_dump') else status_update.dict()
    
    # Broadcast to all connected clients
    for client_id, connection in list(active_connections.items()):
        try:
            await connection.send_json(status_json)
        except Exception:
            # Clean up disconnected clients
            if client_id in active_connections:
                del active_connections[client_id]

# Define the Pulumi program
def pulumi_program(resource_data: Dict[str, Any]):
    # Extract values from the resource_data dictionary, with defaults
    rg_name = resource_data.get("resourceGroupName", "")
    vnet_name = resource_data.get("vnetName", "")
    vnet_cidr = resource_data.get("vnetCidr", "10.0.0.0/16")
    subnet_name = resource_data.get("subnetName", "")
    subnet_cidr = resource_data.get("subnetCidr", "10.0.1.0/24")
    location = resource_data.get("location", "eastus")
    try_import = resource_data.get("tryImportExisting", False)
    
    # If not trying to import, override the function
    if not try_import:
        global check_resource_exists
        def check_resource_exists(resource_id):
            return False
    
    # Create resources
    resource_group = create_resource_group(rg_name, location)
    
    # Create VNet with explicit dependency on resource group
    vnet = create_vnet(
        vnet_name, 
        vnet_cidr, 
        rg_name, 
        location, 
        opts=pulumi.ResourceOptions(depends_on=[resource_group])
    )
    
    # Create Subnet with explicit dependency on VNet
    subnet = create_subnet(
        subnet_name, 
        subnet_cidr, 
        rg_name, 
        vnet_name, 
        opts=pulumi.ResourceOptions(depends_on=[vnet, resource_group])
    )
    
    # Export the resource IDs
    pulumi.export("resourceGroupId", resource_group.id)
    pulumi.export("vnetId", vnet.id)
    pulumi.export("subnetId", subnet.id)
    
    # Export expected creation order for the frontend to use
    creation_order = [
        {"resource_type": "resource_group", "name": rg_name, "depends_on": []},
        {"resource_type": "vnet", "name": vnet_name, "depends_on": ["resource_group"]},
        {"resource_type": "subnet", "name": subnet_name, "depends_on": ["vnet", "resource_group"]}
    ]
    pulumi.export("expected_order", creation_order)
    
    # Return the resource names
    pulumi.export("resourceGroupName", rg_name)
    pulumi.export("vnetName", vnet_name)
    pulumi.export("subnetName", subnet_name)

# Define custom output handler to track resource creation
async def handle_pulumi_output(text, request):
    print(text)
    # Process Pulumi output to identify resource creation events
    text = text.strip().lower()
    
    # Include exact time in status updates
    current_time = datetime.now().strftime("%H:%M:%S.%f")[:-3]
    details = {"raw_output": text, "exact_time": current_time}
    
    # Track when resources are actually created to build a runtime creation order
    creation_sequence = []
    
    # Detect running resources after they're created
    if "running" in text or "started" in text or "active" in text:
        if "resource group" in text:
            await broadcast_resource_status(
                resource_type="resource_group",
                name=request.resourceGroupName,
                status="in_progress",
                message=f"Resource Group running",
                details=details,
                progress=100.0,
                stage="running"
            )
            creation_sequence.append("resource_group")
        elif "virtual network" in text or "vnet" in text:
            await broadcast_resource_status(
                resource_type="vnet",
                name=request.vnetName,
                status="in_progress",
                message=f"Virtual Network running",
                details=details,
                progress=100.0,
                stage="running"
            )
            creation_sequence.append("vnet")
        elif "subnet" in text:
            await broadcast_resource_status(
                resource_type="subnet",
                name=request.subnetName,
                status="in_progress",
                message=f"Subnet running",
                details=details,
                progress=100.0,
                stage="running"
            )
            creation_sequence.append("subnet")
    
    # Detect resource created events
    elif "created" in text or "provisioned" in text or "succeeded" in text:
        if "resource group" in text:
            await broadcast_resource_status(
                resource_type="resource_group",
                name=request.resourceGroupName,
                status="complete",
                message=f"Resource Group created successfully",
                details=details,
                progress=100.0,
                stage="completed"
            )
            creation_sequence.append("resource_group")
        elif "virtual network" in text or "vnet" in text:
            await broadcast_resource_status(
                resource_type="vnet",
                name=request.vnetName,
                status="complete",
                message=f"Virtual Network created successfully",
                details=details,
                progress=100.0,
                stage="completed"
            )
            creation_sequence.append("vnet")
        elif "subnet" in text:
            await broadcast_resource_status(
                resource_type="subnet",
                name=request.subnetName,
                status="complete",
                message=f"Subnet created successfully",
                details=details,
                progress=100.0,
                stage="completed"
            )
            creation_sequence.append("subnet")
    
    # Detect deletion operations
    elif "deleting" in text or "removing" in text:
        if "resource group" in text:
            await broadcast_resource_status(
                resource_type="resource_group",
                name=request.resourceGroupName,
                status="in_progress",
                message=f"Deleting Resource Group...",
                details=details,
                progress=30.0,
                stage="deleting"
            )
        elif "virtual network" in text or "vnet" in text:
            await broadcast_resource_status(
                resource_type="vnet",
                name=request.vnetName,
                status="in_progress",
                message=f"Deleting Virtual Network...",
                details=details,
                progress=30.0,
                stage="deleting"
            )
        elif "subnet" in text:
            await broadcast_resource_status(
                resource_type="subnet",
                name=request.subnetName,
                status="in_progress",
                message=f"Deleting Subnet...",
                details=details,
                progress=30.0,
                stage="deleting"
            )
    
    # Detect completed deletions
    elif "deleted" in text or "removed" in text:
        if "resource group" in text:
            await broadcast_resource_status(
                resource_type="resource_group",
                name=request.resourceGroupName,
                status="complete",
                message=f"Resource Group deleted",
                details=details,
                progress=100.0,
                stage="deleted"
            )
        elif "virtual network" in text or "vnet" in text:
            await broadcast_resource_status(
                resource_type="vnet",
                name=request.vnetName,
                status="complete",
                message=f"Virtual Network deleted",
                details=details,
                progress=100.0,
                stage="deleted"
            )
        elif "subnet" in text:
            await broadcast_resource_status(
                resource_type="subnet",
                name=request.subnetName,
                status="complete",
                message=f"Subnet deleted",
                details=details,
                progress=100.0,
                stage="deleted"
            )
    
    # Resource group specific events
    elif "resource group" in text:
        if "creating" in text:
            await broadcast_resource_status(
                resource_type="resource_group",
                name=request.resourceGroupName,
                status="in_progress",
                message=f"Creating Resource Group...",
                details=details,
                progress=15.0,
                stage="initialization"
            )
        elif "validating" in text:
            await broadcast_resource_status(
                resource_type="resource_group",
                name=request.resourceGroupName,
                status="in_progress",
                message=f"Validating Resource Group...",
                details=details,
                progress=40.0,
                stage="validation"
            )
        elif "provisioning" in text:
            await broadcast_resource_status(
                resource_type="resource_group",
                name=request.resourceGroupName,
                status="in_progress",
                message=f"Provisioning Resource Group...",
                details=details,
                progress=70.0,
                stage="provisioning"
            )
        elif "created" in text:
            await broadcast_resource_status(
                resource_type="resource_group",
                name=request.resourceGroupName,
                status="complete",
                message=f"Resource Group created successfully",
                details=details,
                progress=100.0,
                stage="completed"
            )
            creation_sequence.append("resource_group")
        elif "skipped" in text or "already exists" in text:
            await broadcast_resource_status(
                resource_type="resource_group",
                name=request.resourceGroupName,
                status="complete",
                message=f"Resource Group already exists",
                details=details,
                progress=100.0,
                stage="skipped"
            )
    
    elif "virtual network" in text or "vnet" in text:
        if "creating" in text:
            await broadcast_resource_status(
                resource_type="vnet",
                name=request.vnetName,
                status="in_progress",
                message=f"Creating Virtual Network...",
                details=details,
                progress=10.0,
                stage="initialization"
            )
        elif "validating" in text:
            await broadcast_resource_status(
                resource_type="vnet",
                name=request.vnetName,
                status="in_progress",
                message=f"Validating Virtual Network...",
                details=details,
                progress=30.0,
                stage="validation"
            )
        elif "provisioning" in text:
            await broadcast_resource_status(
                resource_type="vnet",
                name=request.vnetName,
                status="in_progress",
                message=f"Provisioning Virtual Network...",
                details=details,
                progress=60.0,
                stage="provisioning"
            )
        elif "configuring" in text:
            await broadcast_resource_status(
                resource_type="vnet",
                name=request.vnetName,
                status="in_progress",
                message=f"Configuring Virtual Network...",
                details=details,
                progress=80.0,
                stage="configuration"
            )
        elif "created" in text:
            await broadcast_resource_status(
                resource_type="vnet",
                name=request.vnetName,
                status="complete",
                message=f"Virtual Network created successfully",
                details=details,
                progress=100.0,
                stage="completed"
            )
            creation_sequence.append("vnet")
        elif "skipped" in text or "already exists" in text:
            await broadcast_resource_status(
                resource_type="vnet",
                name=request.vnetName,
                status="complete",
                message=f"Virtual Network already exists",
                details=details,
                progress=100.0,
                stage="skipped"
            )
    
    elif "subnet" in text:
        if "creating" in text:
            await broadcast_resource_status(
                resource_type="subnet",
                name=request.subnetName,
                status="in_progress",
                message=f"Creating Subnet...",
                details=details,
                progress=15.0,
                stage="initialization"
            )
        elif "validating" in text:
            await broadcast_resource_status(
                resource_type="subnet",
                name=request.subnetName,
                status="in_progress",
                message=f"Validating Subnet...",
                details=details,
                progress=40.0,
                stage="validation"
            )
        elif "provisioning" in text:
            await broadcast_resource_status(
                resource_type="subnet",
                name=request.subnetName,
                status="in_progress",
                message=f"Provisioning Subnet...",
                details=details,
                progress=70.0,
                stage="provisioning"
            )
        elif "created" in text:
            await broadcast_resource_status(
                resource_type="subnet",
                name=request.subnetName,
                status="complete",
                message=f"Subnet created successfully",
                details=details,
                progress=100.0,
                stage="completed"
            )
            creation_sequence.append("subnet")
        elif "skipped" in text or "already exists" in text:
            await broadcast_resource_status(
                resource_type="subnet",
                name=request.subnetName,
                status="complete",
                message=f"Subnet already exists",
                details=details,
                progress=100.0,
                stage="skipped"
            )
    
    # Detect failures
    elif "error" in text or "failed" in text:
        if "resource group" in text:
            await broadcast_resource_status(
                resource_type="resource_group",
                name=request.resourceGroupName,
                status="failed",
                message=f"Failed to create Resource Group",
                details=details,
                progress=0.0,
                stage="failed"
            )
        elif "virtual network" in text or "vnet" in text:
            await broadcast_resource_status(
                resource_type="vnet", 
                name=request.vnetName,
                status="failed",
                message=f"Failed to create Virtual Network",
                details=details,
                progress=0.0,
                stage="failed"
            )
        elif "subnet" in text:
            await broadcast_resource_status(
                resource_type="subnet",
                name=request.subnetName,
                status="failed",
                message=f"Failed to create Subnet",
                details=details,
                progress=0.0,
                stage="failed"
            )

# This coroutine will handle the async output processing
async def capture_output(stack, request):
    loop = asyncio.get_event_loop()
    
    # Create a queue for output
    output_queue = asyncio.Queue()
    
    # Define sync output handler to put msgs in queue
    def on_output(text):
        loop.call_soon_threadsafe(lambda: output_queue.put_nowait(text))
    
    # Track creation order from output
    creation_order = []
    
    # Track resource state
    resource_states = {
        "resource_group": "pending",
        "vnet": "pending",
        "subnet": "pending"
    }
    
    # Track when resources transition to running state
    running_timestamps = {}
    
    # Start the Pulumi up operation in a thread pool
    up_future = loop.run_in_executor(None, lambda: stack.up(on_output=on_output))
    
    # Process messages in the queue while the operation is running
    while True:
        try:
            # Try to get a message from the queue, timeout after 0.1 second
            text = await asyncio.wait_for(output_queue.get(), 0.1)
            
            # Track creation ordering from output
            if "creating" in text.lower():
                if "resource group" in text.lower():
                    if "resource_group" not in creation_order:
                        creation_order.append("resource_group")
                        resource_states["resource_group"] = "creating"
                elif "virtual network" in text.lower() or "vnet" in text.lower():
                    if "vnet" not in creation_order:
                        creation_order.append("vnet")
                        resource_states["vnet"] = "creating"
                elif "subnet" in text.lower():
                    if "subnet" not in creation_order:
                        creation_order.append("subnet")
                        resource_states["subnet"] = "creating"
            
            # Track when resources are created or running
            if "created" in text.lower():
                if "resource group" in text.lower():
                    resource_states["resource_group"] = "created"
                elif "virtual network" in text.lower() or "vnet" in text.lower():
                    resource_states["vnet"] = "created"
                elif "subnet" in text.lower():
                    resource_states["subnet"] = "created"
            
            # Track resources entering running state
            if "running" in text.lower() or "active" in text.lower() or "started" in text.lower():
                # Save the timestamp when a resource enters running state
                if "resource group" in text.lower() and resource_states["resource_group"] != "running":
                    resource_states["resource_group"] = "running"
                    running_timestamps["resource_group"] = datetime.now()
                elif ("virtual network" in text.lower() or "vnet" in text.lower()) and resource_states["vnet"] != "running":
                    resource_states["vnet"] = "running"
                    running_timestamps["vnet"] = datetime.now()
                elif "subnet" in text.lower() and resource_states["subnet"] != "running":
                    resource_states["subnet"] = "running"
                    running_timestamps["subnet"] = datetime.now()
            
            await handle_pulumi_output(text, request)
        except asyncio.TimeoutError:
            # If the future is done, we're done
            if up_future.done():
                break
    
    # Get the result from the future
    result = await up_future
    
    # After successful deployment, transition resources from running to completed
    if result and result.summary.result == "succeeded":
        # Wait a moment to ensure resources are fully operational
        await asyncio.sleep(2)
        
        # Update dependency information in the frontend
        await broadcast_resource_status(
            resource_type="system",
            name="dependency_info",
            status="info",
            message="Resource creation completed",
            details={"creation_order": creation_order},
            progress=100.0,
            stage="info"
        )
        
        # For each resource, transition from any in-progress state to completed
        for resource_type in ["resource_group", "vnet", "subnet"]:
            # Transition any resource that's not already completed
            if resource_states.get(resource_type) != "complete":
                # Get the resource name based on type
                resource_name = ""
                if resource_type == "resource_group":
                    resource_name = request.resourceGroupName
                elif resource_type == "vnet":
                    resource_name = request.vnetName
                elif resource_type == "subnet":
                    resource_name = request.subnetName
                
                # Calculate duration if we have a timestamp
                duration_info = {}
                if resource_type in running_timestamps:
                    start_time = running_timestamps[resource_type]
                    duration = datetime.now() - start_time
                    duration_seconds = int(duration.total_seconds())
                    duration_info = {
                        "runtime_duration": duration_seconds,
                        "started_at": start_time.isoformat(),
                        "completed_at": datetime.now().isoformat()
                    }
                
                # Send final completed status
                await broadcast_resource_status(
                    resource_type=resource_type,
                    name=resource_name,
                    status="complete",
                    message=f"{resource_name} completed",
                    details=duration_info,
                    progress=100.0,
                    stage="completed"
                )
                
                # Update the resource state
                resource_states[resource_type] = "complete"
    
    return result

@app.post("/api/provision", response_model=ProvisionResponse, responses={500: {"model": ErrorResponse}})
async def provision_infrastructure(request: ProvisionRequest):
    """Provision Azure infrastructure based on the provided request."""
    try:
        # Convert Pydantic model to dict
        if hasattr(request, 'model_dump'):
            request_dict = request.model_dump()
        elif hasattr(request, 'dict'):
            request_dict = request.dict()
        else:
            request_dict = dict(request)
        
        # Set passphrase for Pulumi config encryption
        os.environ["PULUMI_CONFIG_PASSPHRASE"] = "dev-password"
        
        # Setup variables
        project_name = "azure-provisioner"
        stack_name = "dev"
        work_dir = os.getcwd()
        
        # Use create_or_select_stack with a simple error handler
        try:
            # Send status update that we're initializing
            await broadcast_resource_status(
                resource_type="system",
                name="stack",
                status="initializing",
                message="Initializing infrastructure stack"
            )
            
            stack = auto.create_or_select_stack(
                stack_name=stack_name,
                project_name=project_name,
                program=lambda: pulumi_program(request_dict),
                work_dir=work_dir
            )
        except Exception as e:
            await broadcast_resource_status(
                resource_type="system",
                name="stack",
                status="failed",
                message=f"Failed to initialize stack: {str(e)}"
            )
            return JSONResponse(
                status_code=500,
                content={"detail": f"Failed to create or select stack: {str(e)}"}
            )
        
        # Set config and deploy with simple error handlers
        try:
            stack.set_config("azure-native:location", auto.ConfigValue(request.location))
            
            # Add subscription ID from environment variable or use a default/fallback
            # In production, you would get this from a secure source
            subscription_id = os.environ.get(
                "AZURE_SUBSCRIPTION_ID", 
                "d740ae23-de58-429b-ac48-a027167b789b"  # Default from the error message
            )
            stack.set_config("azure-native:subscriptionId", auto.ConfigValue(subscription_id))
        except Exception as e:
            await broadcast_resource_status(
                resource_type="system",
                name="configuration",
                status="failed",
                message=f"Failed to set configuration: {str(e)}"
            )
            return JSONResponse(
                status_code=500,
                content={"detail": f"Failed to set configuration: {str(e)}"}
            )
        
        try:
            # Broadcast that deployment is starting
            await broadcast_resource_status(
                resource_type="system",
                name="deployment",
                status="in_progress",
                message="Starting resource deployment"
            )
            
            # Set all resources to pending with current time
            current_time = datetime.now().strftime("%H:%M:%S.%f")[:-3]
            pending_details = {"state": "queued", "queue_time": current_time}
            
            await broadcast_resource_status(
                resource_type="resource_group",
                name=request.resourceGroupName,
                status="pending",
                message="Resource Group queued for creation",
                details=pending_details,
                progress=0.0,
                stage="queued"
            )
            await broadcast_resource_status(
                resource_type="vnet",
                name=request.vnetName,
                status="pending",
                message="Virtual Network queued for creation",
                details=pending_details,
                progress=0.0,
                stage="queued"
            )
            await broadcast_resource_status(
                resource_type="subnet",
                name=request.subnetName,
                status="pending",
                message="Subnet queued for creation",
                details=pending_details,
                progress=0.0,
                stage="queued"
            )
            
            # Run the capture_output coroutine
            up_result = await capture_output(stack, request)
            
            # Broadcast completion
            await broadcast_resource_status(
                resource_type="system",
                name="deployment",
                status="complete",
                message="Deployment completed successfully"
            )
            
        except Exception as e:
            # Broadcast failure
            await broadcast_resource_status(
                resource_type="system",
                name="deployment",
                status="failed",
                message=f"Deployment failed: {str(e)}"
            )
            
            # Mark all resources as failed
            await broadcast_resource_status(
                resource_type="resource_group",
                name=request.resourceGroupName,
                status="failed",
                message=f"Resource Group creation failed: {str(e)}"
            )
            await broadcast_resource_status(
                resource_type="vnet",
                name=request.vnetName,
                status="failed",
                message=f"Virtual Network creation failed: {str(e)}"
            )
            await broadcast_resource_status(
                resource_type="subnet",
                name=request.subnetName,
                status="failed",
                message=f"Subnet creation failed: {str(e)}"
            )
            
            return JSONResponse(
                status_code=500,
                content={"detail": f"Deployment failed: {str(e)}"}
            )
        
        # Process outputs to make them JSON serializable
        serializable_outputs = {}
        
        for key, value in up_result.outputs.items():
            # Handle Pulumi OutputValue objects
            if hasattr(value, "value"):
                serializable_outputs[key] = value.value
            else:
                # Try to convert to a basic type
                try:
                    serializable_outputs[key] = json.loads(json.dumps(value, default=lambda x: str(x)))
                except:
                    serializable_outputs[key] = str(value)
        
        # Create the successful response
        return ProvisionResponse(
            resourceGroupName=request.resourceGroupName,
            vnetName=request.vnetName,
            subnetName=request.subnetName,
            outputs=serializable_outputs
        )
    
    except Exception as e:
        # Handle any unexpected errors
        await broadcast_resource_status(
            resource_type="system",
            name="error",
            status="failed",
            message=f"Unexpected error: {str(e)}"
        )
        return JSONResponse(
            status_code=500,
            content={"detail": f"Unexpected error: {str(e)}"}
        )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000) 