import pulumi
from pulumi_azure_native import network
from pulumi import Config
from infra.resource_group import check_resource_exists

def create_subnet(name: str, cidr: str, rg_name: str, vnet_name: str, opts=None):
    """
    Create an Azure Subnet within a Virtual Network or import an existing one.
    
    Args:
        name: The name of the subnet.
        cidr: The address prefix in CIDR notation.
        rg_name: The name of the resource group.
        vnet_name: The name of the virtual network.
        opts: Optional resource options for the subnet.
        
    Returns:
        The created or imported subnet.
    """
    # Try to get an existing subnet
    try:
        subscription_id = Config("azure-native").require("subscriptionId")
        subnet_id = f"/subscriptions/{subscription_id}/resourceGroups/{rg_name}/providers/Microsoft.Network/virtualNetworks/{vnet_name}/subnets/{name}"
        
        # Check if the subnet exists before trying to import
        exists = check_resource_exists(subnet_id)
        
        if exists:
            pulumi.log.info(f"Subnet {name} exists, importing it")
            subnet = network.Subnet.get(
                f"{name}-import",
                id=subnet_id
            )
            return subnet
    except Exception as e:
        pulumi.log.warn(f"Error checking if subnet {name} exists: {str(e)}")
        
    # If we get here, either the subnet doesn't exist or we had an error
    # Create a new subnet
    pulumi.log.info(f"Creating new subnet {name}")
    subnet = network.Subnet(
        name,
        resource_group_name=rg_name,
        virtual_network_name=vnet_name,
        subnet_name=name,
        address_prefix=cidr,
        opts=opts
    )
    
    return subnet 