import pulumi
from pulumi_azure_native import network
from pulumi import Config
from infra.resource_group import check_resource_exists

def create_vnet(name: str, cidr: str, rg_name: str, location: str, opts=None):
    """
    Create an Azure Virtual Network or import an existing one.
    
    Args:
        name: The name of the virtual network.
        cidr: The address space in CIDR notation.
        rg_name: The name of the resource group.
        location: The Azure region where the VNet will be created.
        opts: Optional resource options for the virtual network.
        
    Returns:
        The created or imported virtual network.
    """
    # Try to get an existing VNet
    try:
        subscription_id = Config("azure-native").require("subscriptionId")
        vnet_id = f"/subscriptions/{subscription_id}/resourceGroups/{rg_name}/providers/Microsoft.Network/virtualNetworks/{name}"
        
        # Check if the VNet exists before trying to import
        exists = check_resource_exists(vnet_id)
        
        if exists:
            pulumi.log.info(f"VNet {name} exists, importing it")
            vnet = network.VirtualNetwork.get(
                f"{name}-import",
                id=vnet_id
            )
            return vnet
    except Exception as e:
        pulumi.log.warn(f"Error checking if VNet {name} exists: {str(e)}")
        
    # If we get here, either the VNet doesn't exist or we had an error
    # Create a new VNet
    pulumi.log.info(f"Creating new VNet {name}")
    vnet = network.VirtualNetwork(
        name,
        resource_group_name=rg_name,
        virtual_network_name=name,
        location=location,
        address_space=network.AddressSpaceArgs(
            address_prefixes=[cidr]
        ),
        opts=opts
    )
    
    return vnet 