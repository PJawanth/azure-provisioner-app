import pulumi
from pulumi_azure_native import resources
from pulumi import Config

def create_resource_group(name: str, location: str, opts=None):
    """
    Create an Azure Resource Group or import an existing one.
    
    Args:
        name: The name of the resource group.
        location: The Azure region where the resource group will be created.
        opts: Optional resource options.
        
    Returns:
        The created or imported resource group.
    """
    # First check if the resource exists using Azure SDK
    # This is the most reliable way to check
    try:
        # Try to import existing resource group
        subscription_id = Config("azure-native").require("subscriptionId")
        rg_id = f"/subscriptions/{subscription_id}/resourceGroups/{name}"
        
        # Check if the resource group exists before trying to import it
        exists = check_resource_exists(rg_id)
        
        if exists:
            pulumi.log.info(f"Resource group {name} exists, importing it")
            resource_group = resources.ResourceGroup.get(
                f"{name}-import",
                id=rg_id
            )
            return resource_group
    except Exception as e:
        pulumi.log.warn(f"Error checking if resource group exists: {str(e)}")
    
    # If we get here, either the resource doesn't exist or we had an error
    # In either case, we'll try to create it
    pulumi.log.info(f"Creating resource group {name}")
    resource_group = resources.ResourceGroup(
        name,
        resource_group_name=name,
        location=location,
        opts=opts
    )
    return resource_group

def check_resource_exists(resource_id):
    """
    Check if a resource exists by ID - placeholder function.
    In a real implementation, you would use Azure SDK to check.
    """
    # In this simplified version, we'll assume the resource doesn't exist
    # and let the create operation handle any conflicts
    return False 